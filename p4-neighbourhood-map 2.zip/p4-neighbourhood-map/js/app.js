let locationData = [{
    id: "B000A8URXB",
    latitude: "39.989684",
    longitude: "116.480989",
    name: "北京方恒假日酒店"
}, {
    id: "B000A1853E",
    latitude: "39.988911",
    longitude: "116.479856",
    name: "国际竹藤大厦"
}];

locationData = places//places 变量从 data.js 中获得

let map,infoWindow;

function init() {
    map = new AMap.Map('map',{
        zoom:15,
        center: [116.480989, 39.989759]
    });


    locationData.forEach(function (data) {
            console.log(data.longitude);
            let lngLat = new AMap.LngLat(Number(data.longitude),Number(data.latitude));

            // 创建 marker
            let marker = new AMap.Marker({
                position: lngLat,
                title: data.name,
                clickable: true,
                map: map
            });

            console.log(marker);      })
}


init();
