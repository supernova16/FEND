# Neiberhood Map - 上海米其林星际餐厅地图 2018

## Intro

根据米其林官方公布的上海米其林星际餐厅名单制作成的地图。


## 学以致用

- Google Map Api / 高德地图 Api / Foursquare APi
- Knockout JS / MVVM
- Ajax

https://favicon.io/emoji-favicons


## 使用

在线网址：


## References & Data Sources

- [Google Map Api 文档](https://developers.google.com/maps/documentation/javascript/)
- [Foursquare Api 文档](https://developer.foursquare.com/docs/api)



米其林官网上没有上海的地图：https://guide.michelin.com/tw/taipei，中文官网也无法访问:)
